import React, {useState, useEffect} from "react";
import StoreLocator from './views/StoreLocator';
import './App.css';



function App() {
  return (
    <StoreLocator/>
  );
}

export default App;
